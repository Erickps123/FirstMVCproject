﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProfesoresdelItlaMVC.Models;

namespace ProfesoresdelItlaMVC.Data
{
    public class Datos: DbContext
    {
        public Datos(DbContextOptions<Datos> options)
            : base(options)
        {
        }

        public DbSet<Modelo> Dato { get; set; }
    }
}
