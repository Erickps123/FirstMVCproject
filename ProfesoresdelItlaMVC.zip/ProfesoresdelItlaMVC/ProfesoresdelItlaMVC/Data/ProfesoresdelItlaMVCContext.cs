﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProfesoresdelItlaMVC.Models;

namespace ProfesoresdelItlaMVC.Data
{
    public class ProfesoresdelItlaMVCContext : DbContext
    {
        public ProfesoresdelItlaMVCContext (DbContextOptions<ProfesoresdelItlaMVCContext> options)
            : base(options)
        {
        }

        public DbSet<ProfesoresdelItlaMVC.Models.Modelo> Modelo { get; set; }
    }
}
